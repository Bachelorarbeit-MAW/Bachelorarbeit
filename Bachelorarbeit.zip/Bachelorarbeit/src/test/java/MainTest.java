import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    private final static int[] dna = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1};
    private final static char[] dnaWerte = {'A', 'C', 'G', 'T'};
    private final static int[] abc = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
    private final static char[] abcWerte = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();


    /**
     * Testet die Verarbeitung der Parameter.
     * Testauswertung erfolgt manuell, da das Ergebnis eine Konsolenausgabe ist.
     */
    @Test
    void testMain() {
        //<Sequenzdateipfad> <-maw|-lw> <-dna|-abc>
        String[] args = {};
        String[] args1 = {"-h"};
        String[] args2 = {"fail.txt"};
        String[] args3 = {"src/test/dna.txt", "-lw", "-dna"};
        String[] args4 = {"src/test/abc.txt", "-lw", "-abc"};
        String[] args5 = {"src/test/abc.txt", "-maw", "-abc"};


        System.out.println("**********sollte erklären, wie die Hilfe aufgerufen werden kann***************************");
        Main.main(args);    //sollte erklären, wie die Hilfe aufgerufen werden kann
        System.out.println("********sollte die Hilfe ausgeben********************************************************");
        Main.main(args1);   //sollte die Hilfe ausgeben
        System.out.println("****sollte die Datei nicht finden********************************************************");
        Main.main(args2);   //sollte die Datei nicht finden

        System.out.println("**sollte die Distanzmatrix berechnen über DNA*********************************************");
        Main.main(args3);   //sollte die Distanzmatrix berechnen über DNA
        System.out.println(Automat.alphabet);
        System.out.println("******sollte die Distanzmatrix über ABC berechnen****************************************");
        Main.main(args4);   //sollte die Distanzmatrix über ABC berechnen

        System.out.println("******MAW über ABC***********************************************************************");
        Main.main(args5);   //MAW über ABC
        System.out.println("*****************************************************************************************");

    }

    @Test
    void testLwBerechnung() {
        Automat.setAlphabet(dna, dnaWerte);
        assertEquals(4.434166666666666, Main.lwBerechnung("ATGAGTGATAGACC", "GTGGCTATGTTAAC"));
    }

    @Test
    void testLwBerechnung2() {
        Automat.setAlphabet(abc, abcWerte);
        assertEquals(4.434166666666666, Main.lwBerechnung("ATGAGTGATAGACC", "GTGGCTATGTTAAC"));
    }




    @Test
    void testLesen(){
        //prüft das Erkennen eines fehlerhaften FASTA Formats
     assertThrows(Exception.class, () -> Main.lesen(new ArrayList<>(),new ArrayList<>(), new BufferedReader(new FileReader("src/test/keinfasta1.txt")),true));
     assertThrows(Exception.class, () -> Main.lesen(new ArrayList<>(),new ArrayList<>(), new BufferedReader(new FileReader("src/test/keinfasta2.txt")),true));
     assertThrows(Exception.class, () -> Main.lesen(new ArrayList<>(),new ArrayList<>(), new BufferedReader(new FileReader("src/test/keinfasta3.txt")),false));



     try {

         //Prüft die Funktion von dnaMode
         ArrayList<String> sequenzen = new ArrayList<>();
         Main.lesen(sequenzen, new ArrayList<>(), new BufferedReader(new FileReader("src/test/abc.txt")), true);
         assertFalse(sequenzen.get(0).contains("X"));

         sequenzen = new ArrayList<>();
         Main.lesen(sequenzen, new ArrayList<>(), new BufferedReader(new FileReader("src/test/abc.txt")), false);
         assertTrue(sequenzen.get(0).contains("X"));


         //prüft das korrekte Einlesen einer ungewöhnlich formatierten FASTA Datei
         sequenzen = new ArrayList<>();
         Main.lesen(sequenzen, new ArrayList<>(), new BufferedReader(new FileReader("src/test/dnaKomplex.txt")), true);
         assertTrue(sequenzen.get(0).contains("AAACCG"));


     }catch(Exception e){
         fail();
        }

    }

}