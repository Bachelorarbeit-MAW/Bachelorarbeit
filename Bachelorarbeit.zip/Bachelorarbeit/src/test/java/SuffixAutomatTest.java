import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SuffixAutomatTest {
    private final static int[] dna = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1};
    private final static char[] dnaWerte = {'A', 'C', 'G', 'T'};


    /**
     * Testet den MAW Algorithmus unabhängig von der Implementierung des Algorithmus, welcher
     * einen Suffixautomaten für ein Wort erzeugt
     */
    @Test
    void minimalAbsentWord() {
        Automat.setAlphabet(dna, dnaWerte);

        SuffixAutomat auto = new SuffixAutomat();

        Knoten n1 = new Knoten();
        Knoten n2 = new Knoten();
        Knoten n3 = new Knoten();
        Knoten n4 = new Knoten();
        Knoten n5 = new Knoten();
        Knoten n6 = new Knoten();
        Knoten n7 = new Knoten(true, -1);

        Knoten n3__ = new Knoten();
        Knoten n4__ = new Knoten(true, -1);

        Knoten n3_ = new Knoten(true, -1);

        auto.root.isEndOfWord = true;


        //Zustandsübergänge

        auto.root.children[Knoten.deltaIndex('A')] = n1;
        n1.children[Knoten.deltaIndex('A')] = n2;
        n2.children[Knoten.deltaIndex('C')] = n3;
        n3.children[Knoten.deltaIndex('C')] = n4;
        n4.children[Knoten.deltaIndex('A')] = n5;
        n5.children[Knoten.deltaIndex('C')] = n6;
        n6.children[Knoten.deltaIndex('C')] = n7;

        n1.children[Knoten.deltaIndex('C')] = n3__;
        n3__.children[Knoten.deltaIndex('C')] = n4__;
        n4__.children[Knoten.deltaIndex('A')] = n5;

        auto.root.children[Knoten.deltaIndex('C')] = n3_;
        n3_.children[Knoten.deltaIndex('C')] = n4__;
        n3_.children[Knoten.deltaIndex('A')] = n5;

        //SuffixLinks
        n1.suffixLink = auto.root;
        n2.suffixLink = n1;
        n3.suffixLink = n3__;
        n3__.suffixLink = n3_;
        n3_.suffixLink = auto.root;
        n4.suffixLink = n4__;
        n4__.suffixLink = n3_;
        n5.suffixLink = n1;
        n6.suffixLink = n3__;
        n7.suffixLink = n4__;


        Trie ergebnis = auto.minimalAbsentWord();

        assertTrue(ergebnis.find("AAA"));
        assertTrue(ergebnis.find("ACA"));
        assertTrue(ergebnis.find("CCC"));
        assertTrue(ergebnis.find("CAA"));
        assertTrue(ergebnis.find("CACCA"));

    }

    @Test
    void suffixAutomatonConstruction() {
        Automat.setAlphabet(dna, dnaWerte);
        SuffixAutomat test = new SuffixAutomat("AACCACC");
        Trie ergebnis = test.minimalAbsentWord();
        assertTrue(ergebnis.find("AAA"));
        assertTrue(ergebnis.find("ACA"));
        assertTrue(ergebnis.find("CCC"));
        assertTrue(ergebnis.find("CAA"));
        assertTrue(ergebnis.find("CACCA"));

    }

    /**
     * Testet die Suffixautomatenerzeugung, indem die MAW eines erzeugten SA mit den MAW eines manuell erstellten SA verglichen werden.
     */
    @Test
    void suffixAutomatonConstruction2() {
        Automat.setAlphabet(dna, dnaWerte);
        SuffixAutomat auto = new SuffixAutomat();

        Knoten n1 = new Knoten();
        Knoten n2 = new Knoten();
        Knoten n3 = new Knoten();
        Knoten n4 = new Knoten();
        Knoten n5 = new Knoten();
        Knoten n6 = new Knoten();
        Knoten n7 = new Knoten(true, -1);

        Knoten n3__ = new Knoten();
        Knoten n4__ = new Knoten(true, -1);

        Knoten n3_ = new Knoten(true, -1);

        auto.root.isEndOfWord = true;


        //Zustandsübergänge

        auto.root.children[Knoten.deltaIndex('A')] = n1;
        n1.children[Knoten.deltaIndex('A')] = n2;
        n2.children[Knoten.deltaIndex('C')] = n3;
        n3.children[Knoten.deltaIndex('C')] = n4;
        n4.children[Knoten.deltaIndex('A')] = n5;
        n5.children[Knoten.deltaIndex('C')] = n6;
        n6.children[Knoten.deltaIndex('C')] = n7;

        n1.children[Knoten.deltaIndex('C')] = n3__;
        n3__.children[Knoten.deltaIndex('C')] = n4__;
        n4__.children[Knoten.deltaIndex('A')] = n5;

        auto.root.children[Knoten.deltaIndex('C')] = n3_;
        n3_.children[Knoten.deltaIndex('C')] = n4__;
        n3_.children[Knoten.deltaIndex('A')] = n5;

        //SuffixLinks
        n1.suffixLink = auto.root;
        n2.suffixLink = n1;
        n3.suffixLink = n3__;
        n3__.suffixLink = n3_;
        n3_.suffixLink = auto.root;
        n4.suffixLink = n4__;
        n4__.suffixLink = n3_;
        n5.suffixLink = n1;
        n6.suffixLink = n3__;
        n7.suffixLink = n4__;


        Trie ergebnis1 = auto.minimalAbsentWord();

        SuffixAutomat auto2 = new SuffixAutomat("AACCACC");
        Trie ergebnis2 = auto2.minimalAbsentWord();

        assertEquals(ergebnis2.allValues(), ergebnis1.allValues());
    }

    /**
     * Testet Sonderfall der SA Erzeugung
     */
    @Test
    void suffixAutomatonConstruction3() {
        Automat.setAlphabet(dna, dnaWerte);
        SuffixAutomat test = new SuffixAutomat("AAAA");
        Trie ergebnis = test.minimalAbsentWord();
        assertEquals(1, ergebnis.allValues().size());
        assertTrue(ergebnis.find("AAAAA"));
    }


    /**
     * Test gegen eine eigene Berechnung
     */
    @Test
    void maw() {
        Automat.setAlphabet(dna, dnaWerte);
        SuffixAutomat test = new SuffixAutomat("ACGT");

        Trie ergebnis = test.minimalAbsentWord();

        assertEquals("[AA, AG, AT, CA, CC, CT, GA, GC, GG, TA, TC, TG, TT]", ergebnis.allValues().toString());
    }

    /**
     * Test gegen eine eigene Berechnung
     */
    @Test
    void testMAWTiefe() {
        Automat.setAlphabet(dna, dnaWerte);
        SuffixAutomat sa = new SuffixAutomat("AATA");
        Trie t = sa.minimalAbsentWord();

        assertEquals("[3, 3, 3, 2]", t.getWortlängen().toString());
    }
}