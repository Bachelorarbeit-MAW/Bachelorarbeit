import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class KnotenTest {
    private final static int[] dna = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1};
    private final static char[] dnaWerte = {'A', 'C', 'G', 'T'};

    private final static int[] abc = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
    private final static char[] abcWerte = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();


    /**
     * prüft, ob bei falschen Zeichen Fehler erzeugt werden
     */
    @Test
    void deltaIndex() {
        Automat.setAlphabet(dna, dnaWerte);
        assertThrows(Exception.class, () -> Knoten.deltaIndex('X'));
        assertThrows(Exception.class, () -> Knoten.deltaIndex('x'));
        assertThrows(Exception.class, () -> Knoten.deltaIndex('0'));
    }

    /**
     * Testet die Zuweisung aller Werte von A-Z
     */
    @Test
    void testABC() {
        Automat.setAlphabet(abc, abcWerte);
        Trie trie = new Trie();
        trie.insert("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        assertEquals("[ABCDEFGHIJKLMNOPQRSTUVWXYZ]", trie.allValues().toString());
    }
}