import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class TrieTest {
    private final static int[] dna = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1};
    private final static char[] dnaWerte = {'A', 'C', 'G', 'T'};


    /**
     * Testet insert() und find()
     */
    @Test
    void insertAndFindTest() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie trie = new Trie();
        trie.insert("AAA");
        trie.insert("AA");
        trie.insert("AA");
        trie.insert("AACC");
        assertTrue(trie.find("AAA"));
        assertTrue(trie.find("AA"));
        assertTrue(trie.find("AACC"));
        assertFalse(trie.find("TNC"));
    }

    /**
     * Testet allValues()
     */
    @Test
    void allValues() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie trie = new Trie();
        trie.insert("AAA");
        trie.insert("AA");
        trie.insert("AACC");
        assertEquals("[AA, AAA, AACC]", trie.allValues().toString());
    }


    @Test
    void testDifferenz() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie a = new Trie();
        Trie b = new Trie();

        assertEquals(0, Trie.differenz(a, b).allValues().size());

        a.insert("AT");
        a.insert("ATG");
        a.insert("GT");
        assertEquals(3, Trie.differenz(a, b).allValues().size());

        b.insert("AT");
        assertEquals(2, Trie.differenz(a, b).allValues().size());

        Trie c = new Trie();
        assertEquals(0, Trie.differenz(c, a).allValues().size());

    }

    @Test
    void testUnion() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie a = new Trie();
        Trie b = new Trie();

        assertEquals(0, Trie.vereinigung(a, b).allValues().size());

        a.insert("AT");
        a.insert("ATG");
        a.insert("GT");
        assertEquals(3, Trie.vereinigung(a, b).allValues().size());

        b.insert("AT");

        assertEquals(3, Trie.vereinigung(a, b).allValues().size());

        b.insert("AAA");
        assertEquals(4, Trie.vereinigung(a, b).allValues().size());

        Trie c = new Trie();
        assertEquals(3, Trie.vereinigung(c, a).allValues().size());
    }

    @Test
    void testUnion2() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie a = new Trie();
        a.insert("AA");

        Trie b = new Trie();
        b.insert("AAA");

        assertEquals(2, Trie.vereinigung(a, b).allValues().size());
    }

    @Test
    void testSymmetrischeDifferenz() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie t1 = new Trie();
        t1.insert("AA");
        Trie t2 = new Trie();
        t2.insert("AAA");

        assertEquals(2, Trie.symmetrischeDifferenz(t1, t2).allValues().size());
    }

    @Test
    void testGetLängen() {
        Automat.setAlphabet(dna, dnaWerte);
        Trie trie = new Trie();
        trie.insert("ATC");
        trie.insert("AT");
        trie.insert("GGG");
        ArrayList<Integer> res = trie.getWortlängen();
        assertEquals("[2, 3, 3]", res.toString());
    }

}