import java.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;


/**
 * Die Klasse Main beinhaltet die main() Funktion sowie die Funktionen, welche zur Verarbeitung des Inputs benötigt werden.
 */
public class Main {

    //Arrays, die für die Zuordnung von ASCII-Zeichen zum Alphabet nötig sind.
    //DNA
    private final static int[] dna = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1};
    private final static char[] dnaWerte = {'A', 'C', 'G', 'T'};
    //ABC
    private final static int[] abc = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
    private final static char[] abcWerte = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    /**
     * Wird beim Aufruf der JAR ausgeführt.
     * Beinhaltet die Verarbeitung der Eingabe und gibt das gewünschte Ergebnis aus.
     * <p>
     * Optionen:    kein Parameter: Hinweis auf Hilfe wird angezeigt
     * <-h>          : Hilfe wird angezeigt
     *
     * <Sequenzdateipfad> <-maw|-lw> <-dna|-abc>
     * <p>
     * Sequenzen in der Datei müssen im (Multi-)FASTA Format vorliegen
     * Ergebnis wird im Fall der Distanzmatrix in result.phylip gespeichert
     *
     * @param args Parameter, die beim Aufruf aus der Konsole übergeben werden.
     */
    public static void main(String[] args) {

        ArrayList<String> sequenzen = new ArrayList<>();    //beinhaltet die aus der Datei eingelesenen Sequenzen
        ArrayList<String> arten = new ArrayList<>();        //beinhaltet die Artbezeichnung

        if (args.length == 0) {             //kein Parameter übergeben
            System.out.println("Argumente benötigt. -h für Hilfe");

        } else if (Objects.equals(args[0], "-h") || Objects.equals(args[0], "-help")) {     //Hilfe angefordert
            System.out.println("Parameter: <Sequenzdateipfad> <-maw|-lw> <-dna|-abc> \n Sequenzen in der Datei im FASTA Format. ");

        } else {//versuchen, die Datei einzulesen
            System.out.println("Versuche Datei zu lesen...");
            try (BufferedReader br = new BufferedReader(new FileReader(args[0]))) {//prüfen, ob der erste Parameter ein gültiger Dateipfad ist

                //Alphabet Auswertung
                boolean dnaMode = false;
                if (args.length >= 3) {
                    if (Objects.equals(args[2], "-dna")) {
                        Automat.setAlphabet(dna, dnaWerte);
                        dnaMode = true;

                    } else if (Objects.equals(args[2], "-abc")) {
                        Automat.setAlphabet(abc, abcWerte);
                    } else {
                        System.out.println("Unbekanntes Alphabet. Stattdessen wird ABC verwendet.");
                        Automat.setAlphabet(abc, abcWerte);
                    }
                } else {
                    System.out.println("Es wird ABC als Standartalphabet verwendet.");
                    Automat.setAlphabet(abc, abcWerte);
                }

                lesen(sequenzen, arten, br, dnaMode);

                //Auswerten, welche Operation mit den übergebenen Sequenzen angefordert wurde
                if (args.length >= 2 && args[1].equals("-maw")) {   //MAW
                    mawAusgabe(sequenzen, arten);

                } else {   //Distanz
                    if (args.length < 2 || !args[1].equals("-lw")) {
                        System.out.println("unbekannte Operation. Es wird lw verwendet.");
                    }
                    distanzmatrixAusgabe(sequenzen, arten);
                }

                //Fehlerbehandlung
            } catch (FileNotFoundException e) {
                System.out.println("File not found");
            } catch (IOException e) {
                System.out.println("Ein Problem ist aufgetreten. Bitte erneut versuchen!");
            }
        }
    }


    /**
     * Liest die Sequenzen und Artbezeichnungen ein, welche durch den übergebenen BufferedReader aus der FASTA Datei gelesen werden.
     *
     * @param sequenzen ArrayList, in der die Sequenzen gespeichert werden
     * @param arten     Arraylist, in der die Arten gespeichert werden
     * @param br        BufferedReader, der die Datei, welche die Sequenzen im (Multi-)FASTA Format beinhaltet, liest
     * @param dnaMode   im DNA Mode werden alle Zeichen, in dem Sequenzen, welche nicht A,T,C oder G entsprechen, durch eine zufällige Base ersetzt
     * @throws IOException Tritt auf, wenn beim Einlesen der Datei ein Problem auftritt
     */
    public static void lesen(ArrayList<String> sequenzen, ArrayList<String> arten, BufferedReader br, Boolean dnaMode) throws IOException {

        String line;// beinhaltet eingelesene Zeile
        StringBuilder sequenz = new StringBuilder();// beinhaltet (unvollständige) Sequenz
        StringBuilder sbline;

        while ((line = br.readLine()) != null) {
            if (line.charAt(0) == '>' && ((sequenzen.size() == arten.size() && sequenz.isEmpty()) || ((!sequenz.isEmpty()) && sequenzen.size() == arten.size() - 1))) {  //Artbezeichnung + Artbezeichnung möglich
                if (!sequenz.isEmpty()) {                                                  //fängt den Sonderfall bei der ersten Artbezeichnung ab
                    sequenzen.add(sequenz.toString());
                    sequenz = new StringBuilder();                                       // reset für neue Sequenz
                }
                arten.add(line.substring(1));//entfernt > und fügt die Art hinzu
            } else if ((!(line.charAt(0) == '>')) && sequenzen.size() == arten.size() - 1) {// Sequenz + Sequenz möglich
                //bearbeiten der eingelesenen Teilsequenz
                sbline = new StringBuilder(line.replace(" ", ""));

                if (dnaMode) {
                    for (int i = 0; i < sbline.length(); i++) {
                        if (!(sbline.charAt(i) == 'T' || sbline.charAt(i) == 'A' || sbline.charAt(i) == 'C' || sbline.charAt(i) == 'G')) {
                            sbline.replace(i, i + 1, getRandomBase());  //Base ersetzen
                        }
                    }
                }

                sequenz.append(sbline);

            } else {
                throw new InputMismatchException("Datei nicht im FASTA Format");
            }
        }

        //Hinzufügen der letzten Sequenz, nachdem das Dateiende erreicht wurde.
        if (sequenz.isEmpty()) {
            throw new InputMismatchException("Datei nicht im FASTA Format");
        } else {
            sequenzen.add(sequenz.toString());
        }

        System.out.println("....Datei erfolgreich gelesen");
    }


    /**
     * berechnet das Distanzmaß LW_MAW
     * Laufzeitkomplexität: O((|sequenz1| + |sequenz2| ) *|Alphabet|^2)
     *
     * @param sequenz1 Erste Sequenz
     * @param sequenz2 Zweite Sequenz
     * @return Distanz
     */
    public static double lwBerechnung(String sequenz1, String sequenz2) {

        SuffixAutomat suffixAutomaton1 = new SuffixAutomat(sequenz1);
        SuffixAutomat suffixAutomaton2 = new SuffixAutomat(sequenz2);

        Trie maw1 = suffixAutomaton1.minimalAbsentWord();
        Trie maw2 = suffixAutomaton2.minimalAbsentWord();

        Trie symDif = Trie.symmetrischeDifferenz(maw1, maw2);

        ArrayList<Integer> längen = symDif.getWortlängen();

        double sum = 0;
        for (Integer l : längen) {
            sum = sum + (1 / Math.pow(l, 2));
        }

        return sum;
    }


    /**
     * Bestimmt die Distanzmatrix, gibt das Ergebnis aus und speichert das Ergebnis in der result Datei als phylip Distanzmatrix.
     *
     * @param sequenzen Sequenzen, die untersucht werden
     * @param arten     Arten, die untersucht werden
     * @throws IOException tritt auf, falls es ein Problem mit der result Datei gibt
     */
    private static void distanzmatrixAusgabe(ArrayList<String> sequenzen, ArrayList<String> arten) throws IOException {

        System.out.println("Beginne Distanzen zu berechnen");

        //Distanzen berechnen -> Distanzmatrix ist symmetrisch
        double[][] ergebnis = new double[sequenzen.size()][sequenzen.size()];
        double temp;
        for (int i = 0; i < sequenzen.size(); i++) {
            for (int j = i; j < sequenzen.size(); j++) {
                temp = lwBerechnung(sequenzen.get(i), sequenzen.get(j));
                ergebnis[i][j] = temp;
                ergebnis[j][i] = temp;
            }
        }

        //Ausgabe Distanzen
        System.out.println("Distanzmatrix:");
        DecimalFormat formatter = new DecimalFormat("#.##");
        formatter.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
        for (int i = 0; i < sequenzen.size(); i++) {
            for (int j = 0; j < sequenzen.size(); j++) {
                System.out.print(formatter.format(ergebnis[i][j]));
                if (j != sequenzen.size() - 1) System.out.print("\t");
            }
            System.out.println();
        }

        //Ergebnis in Datei speichern
        FileWriter fileWriter = new FileWriter("result.phylip");
        PrintWriter printWriter = new PrintWriter(fileWriter);

        printWriter.print("\t" + sequenzen.size() + "\n");
        for (int i = 0; i < sequenzen.size(); i++) {
            printWriter.print(arten.get(i) + "\t");
            for (int j = 0; j < sequenzen.size(); j++) {
                printWriter.print(formatter.format(ergebnis[i][j]));
                if (j != sequenzen.size() - 1) printWriter.print(" ");
            }
            if (i != sequenzen.size() - 1) {
                printWriter.print("\n");
            }
        }
        printWriter.close();
    }

    /**
     * Funktion, welche die MAW für die übergebenen Sequenzen bestimmt und direkt auf dem Bildschirm sowie in result.txt speichert.
     *
     * @param sequenzen ArrayList, in der die Sequenzen gespeichert sind, für welche die MAW bestimmt werden sollen
     * @param arten     Arraylist, in der die eingelesenen Arten gespeichert sind
     * @throws IOException tritt bei Problemen beim Schreiben der Ergebnisdatei auf
     */
    private static void mawAusgabe(ArrayList<String> sequenzen, ArrayList<String> arten) throws IOException {

        //Bestimmung der MAW
        ArrayList<ArrayList<String>> maw = new ArrayList<>();
        for (String sequenz : sequenzen) {
            maw.add(new SuffixAutomat(sequenz).minimalAbsentWord().allValues());
        }

        //Textausgabe
        System.out.println("MAW:");
        for (int i = 0; i < maw.size(); i++) {
            System.out.println(arten.get(i) + ":");
            System.out.println(maw.get(i) + "\n");
        }

        //MAW in Datei speichern
        FileWriter fileWriter = new FileWriter("result.txt");
        PrintWriter printWriter = new PrintWriter(fileWriter);

        for (int i = 0; i < maw.size(); i++) {
            printWriter.println(arten.get(i) + ":");
            printWriter.println(maw.get(i) + "\n");
        }

        printWriter.close();
    }


    /**
     * Gibt eine zufällige Base als String zurück
     *
     * @return zufällige Base
     */
    private static String getRandomBase() {
        Random rand = new Random();
        return Character.toString(dnaWerte[rand.nextInt(0, 3)]);
    }

}