import java.util.ArrayList;
import java.util.Stack;

/**
 * Die Klasse Automat beinhaltet alle Funktionen und Variablen, die jeder Automat benötigt.
 */
abstract class Automat {

    final Knoten root;              //Wurzel des Automaten
    public static char[] alphabet;  //Beinhaltet das für die Automaten gültige Alphabet
    public static int[] rename;     //weist dem Index des ASCII-Buchstaben den Index im Alphabet des Automaten zu

    /**
     * Setzt die Arrays, die zur Zuordnung der Alphabetbuchstaben benötigt werden
     * Muss aufgerufen werden, bevor das erste Automatobjekt erzeugt wird
     *
     * @param rename   Index-Zuweisungsfunktion
     * @param alphabet Alphabet
     */
    public static void setAlphabet(int[] rename, char[] alphabet) {
        Automat.rename = rename;
        Automat.alphabet = alphabet;
    }

    /**
     * Konstruktor
     */
    Automat() {
        root = new Knoten();
        if (alphabet == null || rename == null) {
            throw new RuntimeException("Alphabet ist nicht definiert");
        }
    }


    /**
     * Bestimmt alle gespeicherten Wörter des Automaten
     * Die Knoten werden im Stil einer Tiefensuche durchsucht. Dabei wird der direkte Pfad von der Wurzel bis zum in
     * allValuesRec(..) betrachteten Knoten in path gespeichert.
     *
     *
     * @return Wortlist
     */
    public ArrayList<String> allValues() {
        Stack<String> path = new Stack<>();             //beinhaltet den Pfad von der Wurzel zum aktuell betrachteten Knoten
        ArrayList<String> ergebnis = new ArrayList<>(); //speichert die gefundenen Wörter
        allValuesRec(root, path, ergebnis);

        return ergebnis;
    }


    /**
     * Hilfsfunktion, die den rekursiven Aufruf für allValues() übernimmt.
     * Ist der Knoten ein Wortende, wird das in path gespeicherte Wort zu ergebnis hinzugefügt.
     *
     * @param node     aktuell betrachteter Knoten im Automaten
     * @param path     Stack, welcher den direkten Pfad von der Wurzel zum aktuell betrachteten Knoten speichert
     * @param ergebnis Liste, welche die gefundenen Wörter speichert
     */
    private void allValuesRec(Knoten node, Stack<String> path, ArrayList<String> ergebnis) {
        if (node != null) {
            if (node.isEndOfWord) {                             //prüfen, ob ein neues Wort gefunden wurde
                ergebnis.add(String.join("", path));   //neues Wort der Ergebnismenge hinzufügen
            }
            for (char a : alphabet) {                           //Aufruf der Kindknoten
                path.push(String.valueOf(a));   //Pfad Aufbau
                allValuesRec(node.delta(a), path, ergebnis);
            }
        }

        if (!path.isEmpty()) {    //Pfad Abbau
            path.pop();
        }
    }

}
