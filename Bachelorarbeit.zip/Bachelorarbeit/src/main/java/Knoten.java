/**
 * Klasse, die die Knoten für SuffixArray und Trie beschreibt
 */
public class Knoten {

    public boolean isEndOfWord; //Wortende/Endzustand
    final Knoten[] children;    //beinhaltet die von diesem Knoten aus erreichbaren Knoten

    boolean reached;            //speichert für bestimmte Algorithmen, ob der Knoten schon erreicht wurde.
    Knoten suffixLink;          //Speichert, falls vorhanden, den Suffix-link
    public int tiefe;           //Anzahl der Knoten zwischen root und dem Knoten

    /**
     * Konstruktor
     */
    Knoten() {
        isEndOfWord = false;
        children = new Knoten[Automat.alphabet.length];
        reached = false;
        suffixLink = null;
        tiefe = 0;
    }

    /**
     * Konstruktor
     */
    Knoten(boolean endOfWord, int tiefe) {
        isEndOfWord = endOfWord;
        children = new Knoten[Automat.alphabet.length];
        reached = false;
        suffixLink = null;
        this.tiefe = tiefe;
    }


    /**
     * Gibt den Knoten zurück, welcher von diesem Knoten über a erreichbar ist
     * Zeichen, die nicht dem Alphabet entsprechen, werden abgefangen.
     *
     * @param a Kantenbeschriftung
     * @return Zielknoten
     * @throws IllegalArgumentException wenn die Kantenbezeichnung nicht Teil des Alphabets ist
     */
    public Knoten delta(char a) throws IllegalArgumentException {
        return children[deltaIndex(a)];
    }


    /**
     * Gibt den Index für das children Array zurück, in dem der Knoten gespeichert ist, der über a erreichbar ist.
     * Zeichen, die nicht dem Alphabet entsprechen, werden abgefangen.
     *
     * @param a Kantenbezeichnung
     * @return Index für children Array
     * @throws IllegalArgumentException wenn die Kantenbezeichnung nicht Teil des Alphabets ist
     */
    public static int deltaIndex(char a) throws IllegalArgumentException {
        if (a - 'A' >= 26 || a - 'A' < 0)
            throw new IllegalArgumentException("Falscher Buchstabe");//Kein Zeichen zwischen A-Z
        else {
            int result = Automat.rename[a - 'A'];
            if (result != -1)//-1 = falscher Buchstabe
                return result;
            else
                throw new IllegalArgumentException("Sequenz beinhaltet Zeichen, die nicht Teil des Alphabets sind. (" + a + ")");
        }
    }

}