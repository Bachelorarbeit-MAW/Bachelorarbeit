import java.util.ArrayList;
import java.util.List;

/**
 * Beinhaltet die Funktionen für den Trie
 */
public class Trie extends Automat {

    /**
     * Bestimmt die Längen der Wörter, die im Trie gespeichert sind.
     * jeder Knoten wird von recLängen(..) einmal betrachtet.
     * -> Laufzeitkomplexität O(|Knotenanzahl|*|Alphabet|)
     *
     * @return Wortlängen
     */
    public ArrayList<Integer> getWortlängen() {
        ArrayList<Integer> result = new ArrayList<>(); //Liste, in der die Längen gespeichert werden
        recLängen(root, result);
        return result;
    }

    /**
     * Hilfsfunktion für getWortlängen(), welche den rekursiven Aufruf übernimmt.
     *
     * Die Knoten werden im Stil einer Tiefensuche durchsucht.
     * Wird ein Wortende gefunden, wird die Tiefe zur Ergebnisliste hinzugefügt.
     *
     * @param n    aktuell betrachteter Knoten
     * @param list Liste, in der die Längen gespeichert werden sollen
     */
    private void recLängen(Knoten n, List<Integer> list) {
        if (n != null) {
            if (n.isEndOfWord)
                list.add(n.tiefe);
            for (char a : alphabet) {
                recLängen(n.delta(a), list);
            }
        }
    }

    /**
     * Erzeugt als Ergebnis einen identischen Trie
     * ACHTUNG: SUFFIX LINK WIRD NICHT KOPIERT (weil nicht notwendig für die Anwendung)
     *
     * Jeder Knoten wird von recCopy(..) einmal betrachtet.
     * -> Laufzeitkomplexität O(|Knotenanzahl|*|Alphabet|)
     *
     * @return Identischer Trie
     */
    private Trie deepCopy() {
        Trie copy = new Trie();
        recCopy(this.root, copy.root);
        return copy;
    }

    /**
     * Hilfsfunktion für deepCopy, welche den rekursiven Aufruf übernimmt.
     * Der Originalknoten wird im Stil einer Tiefensuche durchlaufen und die Kopie parallel dazu aufgebaut.
     *
     * @param o aktuell betrachteter Knoten aus dem Original-Trie
     * @param c Knoten, der die Werte des Originalknoten übernehmen soll
     */
    private void recCopy(Knoten o, Knoten c) {
        //Werte kopieren
        c.isEndOfWord = o.isEndOfWord;
        c.tiefe = o.tiefe;
        c.reached = o.reached;

        //Neue Knoten bei Bedarf hinzufügen
        for (char w : alphabet) {
            if (o.delta(w) != null) {
                Knoten node = new Knoten();
                c.children[Knoten.deltaIndex(w)] = node;
                recCopy(o.delta(w), node);
            }
        }
    }


    //Mengenoperationen********************************

    /**
     * Bestimmt die Differenz zweier Tries, ohne die übergebenen Tries zu verändern.
     *
     * Laufzeitkomplexität: O(|A|*|Alphabet|)
     *
     * @param a Trie A
     * @param b Trie B
     * @return Differenz
     */
    public static Trie differenz(Trie a, Trie b) {
        Trie dif = a.deepCopy();
        recDif(dif.root, b.root);
        return dif;
    }

    /**
     * Hilfsfunktion für differenz().
     * Die Knoten werden im Stil einer Tiefensuche parallel durchsucht.
     * Hat der Knoten aus Trie A an derselben Stelle wie Trie B ein Wortende, wird in Trie A das Wortende entfernt.
     *
     * @param a Knoten aus Trie A
     * @param b Knoten aus Trie B
     */
    private static void recDif(Knoten a, Knoten b) {
        if (a != null && b != null) {
            if (a.isEndOfWord && b.isEndOfWord) {
                a.isEndOfWord = false;  //entfernt Wort
            }
            for (char w : alphabet) {
                if (a.delta(w) != null && b.delta(w) != null) {
                    recDif(a.delta(w), b.delta(w));
                }
            }
        }
    }

    /**
     * Bestimmt die Vereinigung zweier Tries, ohne die übergebenen Tries zu verändern.
     * Kopien von Trie A und B werden parallel im Stil einer Tiefensuche durchlaufen.
     * Falls B an einer Stelle ein Wortende vermerkt, erhält auch A ein Wortende.
     * Fehlt A ein kompletter Ast von B, wird dieser im Ganzen übernommen.
     *
     * Laufzeitkomplexität: O((|A|+|B|)*|Alphabet|)
     *
     * @param a Trie A
     * @param b Trie B
     * @return Trie mit den Wörtern aus beiden Tries
     */
    public static Trie vereinigung(Trie a, Trie b) {
        Trie copyA = a.deepCopy();
        Trie copyB = b.deepCopy();
        recVereinigung(copyA.root, copyB.root);
        return copyA;
    }

    /**
     * Hilfsfunktion für vereinigung() welche den rekursiven aufruf übernimmt
     *
     * @param a Knoten aus Trie A
     * @param b Knoten aus Trie B
     */
    private static void recVereinigung(Knoten a, Knoten b) {

        if (b != null) {//Hat b überhaupt etwas, das zu a hinzugefügt werden kann?
            if (b.isEndOfWord) {    //neues Wort hinzufügen
                a.isEndOfWord = true;
            }
            for (char w : alphabet) {
                if (a.delta(w) == null && b.delta(w) != null) { //hat b einen Ast, den a nicht hat?
                    a.children[Knoten.deltaIndex(w)] = b.delta(w);// zu a den Ast von b hinzufügen
                } else
                    recVereinigung(a.delta(w), b.delta(w));           //sonst rekursiv weiter vergleichen
            }
        }
    }

    /**
     * Bestimmt die Symmetrische Differenz zweier Tries, ohne die übergebenen Tries zu verändern.
     *
     * Laufzeitkomplexität: O((|A|+|B|)*|Alphabet|)
     *
     * @param a Trie A
     * @param b Trie B
     * @return Symmetrische Differenz
     */
    public static Trie symmetrischeDifferenz(Trie a, Trie b) {

        return vereinigung(differenz(a, b), differenz(b, a));
    }


    //Hilfsfunktionen für die Tests*****************************************

    /**
     * Hilfsfunktion für die Tests, welche dem Trie einen String hinzufügt.
     *
     * @param in hinzuzufügendes Wort
     */
    public void insert(String in) {
        Knoten node = root;

        for (int i = 0; i < in.length(); i++) { //Pfad Zeichen für Zeichen suchen
            if (node.delta(in.charAt(i)) == null) { // Gibt es eine Kante mit passender Kantenbezeichnung?
                node.children[Knoten.deltaIndex(in.charAt(i))] = new Knoten(false, i + 1);  // Kante und zugehöriger Knoten, die noch nicht existiert, hinzufügen
            }
            node = node.delta(in.charAt(i));
        }
        node.isEndOfWord = true;
    }

    /**
     * Hilfsfunktion für die Tests, welche prüft, ob ein übergebener String im Trie gespeichert ist.
     * Dem Pfad so lange folgen, bis das passende Wortende erreicht wurde, sonst false.
     *
     * @param s gesucht
     * @return gefunden
     */
    public boolean find(String s) {
        Knoten node = root;

        for (int i = 0; i < s.length(); i++) {
            if (node.delta(s.charAt(i)) == null) {
                return false;
            } else {
                node = node.delta(s.charAt(i));
            }
        }
        return node.isEndOfWord;
    }

}