import org.javatuples.Pair;

import java.util.ArrayList;
import java.util.List;

public class SuffixAutomat extends Automat {


    /**
     * Konstruktor, der nur von den Testklassen verwendet wird.
     */
    SuffixAutomat() {
        super();
    }


    /**
     * Konstruktor, der den Suffixautomaten zu einem String erzeugt.
     *
     * @param s String, dessen Suffixautomat erzeugt werden soll.
     */
    SuffixAutomat(String s) {

        super();
        Knoten last = root;

        for (char a : s.toCharArray()) {

            //Extension
            Knoten newKnoten = new Knoten();
            newKnoten.tiefe = last.tiefe + 1;
            Knoten p = last;

            do {
                p.children[Knoten.deltaIndex(a)] = newKnoten;
                p = p.suffixLink;
            } while (p != null && p.delta(a) == null);

            if (p == null) {
                newKnoten.suffixLink = root;
            } else {
                Knoten q = p.delta(a);
                if (p.tiefe + 1 == q.tiefe) {
                    newKnoten.suffixLink = q;
                } else {
                    Knoten clone = new Knoten();
                    clone.tiefe = p.tiefe + 1;
                    for (char b : alphabet) {
                        if (q.delta(b) != null)
                            clone.children[Knoten.deltaIndex(b)] = q.delta(b);
                    }

                    newKnoten.suffixLink = clone;
                    clone.suffixLink = q.suffixLink;
                    q.suffixLink = clone;

                    do {
                        p.children[Knoten.deltaIndex(a)] = clone;
                        p = p.suffixLink;
                    } while (p != null && p.delta(a) == q);
                }
            }
            last = newKnoten;
            //end extension
        }

        Knoten p = last;
        do {
            p.isEndOfWord = true;
            p = p.suffixLink;
        } while (p != null);

    }


    /**
     * Berechnet die Minimal Absent Words auf Basis des SuffixAutomaten
     *
     * @return MAW-Trie
     */
    public Trie minimalAbsentWord() {
        Trie m = new Trie();        //speichert die MAW
        List<Pair<Knoten, Knoten>> list = new ArrayList<>();
        list.add(new Pair<>(root, m.root));

        while (!list.isEmpty()) {
            Knoten p = list.get(0).getValue0();
            Knoten p_ = list.get(0).getValue1();
            p.reached = true;
            list.remove(0);

            for (char a : Automat.alphabet) {
                if ((p.delta(a) == null) && (p.suffixLink != null && p.suffixLink.delta(a) != null)) {
                    Knoten q_ = new Knoten(true, p_.tiefe + 1);
                    p_.children[Knoten.deltaIndex(a)] = q_;

                } else if (p.delta(a) != null && !p.delta(a).reached) {
                    Knoten q_ = new Knoten(false, p_.tiefe + 1);
                    p_.children[Knoten.deltaIndex(a)] = q_;
                    list.add(new Pair<>(p.delta(a), q_));
                    p.delta(a).reached = true;
                }
            }
        }

        return m;
    }
}